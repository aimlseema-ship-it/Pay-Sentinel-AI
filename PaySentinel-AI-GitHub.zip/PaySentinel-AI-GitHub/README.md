# PaySentinel AI

A responsive front-end hackathon prototype for payment risk monitoring. It includes a dashboard, transaction scanner, sample fraud alerts, risk analytics and CSV report export.

## Run locally
1. Download or clone this repository.
2. Open `index.html` in a modern browser. No build step is required.
3. Internet access is needed to load Chart.js and Google Fonts from their CDNs; the core scanner works without a backend.

## Publish on GitHub Pages
1. Create a GitHub repository, for example `paysentinel-ai`.
2. Upload `index.html`, `style.css`, `app.js`, and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. Wait for the Pages URL to appear.

## Important limitations
- This is a front-end demo with illustrative data and explainable heuristic rules, not a trained AI model.
- It does not connect to PayPal, bank accounts, payment processors, or real transaction feeds.
- Do not enter real personal, financial, or payment credentials. Do not use demo scores to make real payment decisions.
- For a production implementation, add a secure backend, authenticated APIs, privacy controls, model evaluation, audit logging and appropriate security review.
